<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Information</title>
    <link rel="stylesheet" href="styless.css">
</head>
<body>
    <div class="logo">
        <img src="images/Kales22.png" alt="Company Logo" width="150">
    </div>
    <div class="order-details">
        <h2>Order Information</h2>
        <form id="order-form">
            <div class="input-container">
                <label for="order-date">Date:</label>
                <input type="text" id="order-date" name="order_date" readonly>
            </div>
            <div class="input-container">
                <label for="customer-name">Customer Name:</label>
                <input type="text" id="customer-name" name="customer_name" required>
            </div>
            <div class="input-container">
                <label for="customer-contact">Customer Contact:</label>
                <input type="text" id="customer-contact" name="customer_contact" required>
            </div>
            <div class="input-container">
                <button type="button" onclick="addItem()">Add Item</button>
            </div>
        </form>

        <h3>Order Items</h3>
        <table>
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Price (each)</th>
                    <th>Total Price</th>
                </tr>
            </thead>
            <tbody id="order-items">
                <!-- Order items will be added here dynamically -->
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                    <td id="total-price">Ugx 0.00</td>
                </tr>
            </tfoot>
        </table>
        <div class="footer">
            <button type="button" onclick="generateReceipt()">Generate Receipt</button>
            <p class="warning" id="warning-message" style="display: none;">Please fill in all required fields.</p>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            document.getElementById('order-date').value = today.toDateString();
        });

        let itemIndex = 0;
        function addItem() {
            const itemName = prompt("Enter item name:");
            const quantity = parseInt(prompt("Enter quantity:"), 10);
            const priceEach = parseFloat(prompt("Enter price (each):"), 10);
            const totalPrice = quantity * priceEach;

            const orderItemsTable = document.getElementById('order-items');
            const orderItemRow = `
                <tr id="item-${itemIndex}">
                    <td>${itemName}</td>
                    <td>${quantity}</td>
                    <td>Ugx ${formatCurrency(priceEach)}</td>
                    <td>Ugx ${formatCurrency(totalPrice)}</td>
                </tr>
            `;
            orderItemsTable.insertAdjacentHTML('beforeend', orderItemRow);

            updateTotalPrice();
            itemIndex++;
        }

        function formatCurrency(amount) {
            return amount.toLocaleString('en-UG');
        }

        function updateTotalPrice() {
            let total = 0.00;
            const rows = document.querySelectorAll('#order-items tr');
            rows.forEach(row => {
                const price = parseFloat(row.cells[3].textContent.replace('Ugx ', '').replace(/,/g, ''));
                total += price;
            });
            document.getElementById('total-price').textContent = `Ugx ${formatCurrency(total)}`;
        }

        function generateReceipt() {
            const form = document.getElementById('order-form');
            const inputs = form.querySelectorAll('input[required]');
            let valid = true;

            inputs.forEach(input => {
                if (!input.value) {
                    valid = false;
                }
            });

            if (!valid) {
                document.getElementById('warning-message').style.display = 'block';
                return;
            } else {
                document.getElementById('warning-message').style.display = 'none';
            }

            const orderNumber = `ORD-${new Date().getTime()}`;
            const orderDate = document.getElementById('order-date').value;
            const customerName = document.getElementById('customer-name').value;
            const customerContact = document.getElementById('customer-contact').value;
            const items = [];
            const rows = document.querySelectorAll('#order-items tr');
            rows.forEach(row => {
                const item = {
                    name: row.cells[0].textContent,
                    quantity: row.cells[1].textContent,
                    priceEach: row.cells[2].textContent,
                    totalPrice: row.cells[3].textContent,
                };
                items.push(item);
            });

            // Fetch the total price
            const totalPrice = document.getElementById('total-price').textContent.replace('Ugx', '').replace(/,/g, '').trim();

            const receiptData = {
                orderNumber,
                orderDate,
                customerName,
                customerContact,
                items,
                totalPrice,
                orderTime: new Date().toLocaleTimeString()
            };

            // Send the data to the PHP script
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "insert_order.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function() {
                if (xhr.status === 200) {
                    const receiptWindow = window.open('', '_blank');
                    receiptWindow.document.write(xhr.responseText);
                    receiptWindow.document.close();
                } else {
                    alert("An error occurred while saving the order. Please try again.");
                }
            };
            xhr.send("orderReceipt=" + encodeURIComponent(JSON.stringify(receiptData)));
        }
    </script>
</body>
</html>
