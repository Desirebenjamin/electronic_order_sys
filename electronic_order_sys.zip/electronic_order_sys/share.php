<?php
// Start the session to access session variables
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "order_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve order number and total price from POST
$orderNumber = $_POST['orderNumber'];
$totalPrice = $_POST['totalPrice']; // Retrieve the total price

// Fetch order details from database
$stmt = $conn->prepare("SELECT * FROM orders WHERE order_number = ?");
$stmt->bind_param("s", $orderNumber);
$stmt->execute();
$result = $stmt->get_result();
$orderData = $result->fetch_assoc();

$stmt->close();
$conn->close();

// Decode items JSON
$items = json_decode($orderData['items'], true);

// Get the current logged-in user from the session
$preparedBy = $_SESSION['username'] ?? 'Unknown User';

// Generate the receipt HTML content 
$receiptHtml = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            max-width: 400px;
            margin: 20px auto;
            background-color: #f0f8ff;
            color: #0073e6;
        }
        .content-container {
            padding: 10px;
            border: 1px solid #0073e6;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }
        .logo {
            text-align: center;
            margin-bottom: 10px;
        }
        .logo h1 {
            color: #0000FF;
            font-size: 24px;
            margin: 0;
        }
        .logo h2 {
            color: #0000FF;
            font-size: 18px;
            margin: 0;
        }
        #receipt-content {
            padding: 10px;
        }
        .order-details {
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        table, th, td {
            border: 1px solid #0073e6;
            padding: 5px;
            text-align: left;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            color: #666;
            font-size: 10px;
        }
        .prepared-by {
            margin-top: 20px;
            font-size: 12px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="content-container">
        <div class="logo" style="text-align: center;">
            <h1 style="color: #0000FF; font-size: 24px; margin: 0;">Kales22 Beverages</h1>
            <h2 style="color: #0000FF; font-size: 18px; margin: 0;">(U) Limited</h2>
        </div>
        <div id="receipt-content">
            <div class="order-details">
                <h2>Order Receipt</h2>
                <p><strong>Order Number:</strong> ' . htmlspecialchars($orderData['order_number']) . '</p>
                <p><strong>Date:</strong> ' . htmlspecialchars($orderData['order_date']) . '</p>
                <p><strong>Time:</strong> ' . htmlspecialchars($orderData['order_time']) . '</p>
                <p><strong>Customer Name:</strong> ' . htmlspecialchars($orderData['customer_name']) . '</p>
                <p><strong>Customer Contact:</strong> ' . htmlspecialchars($orderData['customer_contact']) . '</p>

                <h3>Order Items</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Price (each)</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>';

foreach ($items as $item) {
    $receiptHtml .= '
    <tr>
        <td>' . htmlspecialchars($item['name']) . '</td>
        <td>' . htmlspecialchars($item['quantity']) . '</td>
        <td>' . htmlspecialchars($item['priceEach']) . '</td>
        <td>' . htmlspecialchars($item['totalPrice']) . '</td>
    </tr>';
}

$receiptHtml .= '
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                            <td>' . htmlspecialchars($totalPrice) . '</td>
                        </tr>
                    </tfoot>
                </table>
                <div class="prepared-by">
                    <p><strong>Prepared By:</strong> ' . htmlspecialchars($preparedBy) . '</p>
                </div>
            </div>
        </div>
        <div class="footer">
            <p>' . date("Y-m-d H:i:s") . '</p>
        </div>
    </div>
</body>
</html>';

// Associative array of target computers and their UNC paths to the client (server) shared folder
$targetPaths = [
    
    'DESKTOP-QGUME3Q' => 'C:\\Users\\DELL\\Desktop\\SharedReceipts',
    
    // Add other target computers and their paths here
];

foreach ($targetPaths as $target => $sharedFolderPath) {
    // Construct the target path using the UNC path format
    $targetPath = $sharedFolderPath;

    // Check if the directory exists, if not create it
    if (!file_exists($targetPath)) {
        if (!mkdir($targetPath, 0777, true)) {
            echo 'Failed to create folder on ' . $target . '<br>';
            continue;
        }
    }

    // Full path for the receipt file
    $receiptFilePath = $targetPath . '\\receipt_' . $orderNumber . '.html';

    // Save the receipt file to the target path
    if (file_put_contents($receiptFilePath, $receiptHtml)) {
        echo 'Receipt shared to ' . $target . '<br>';
    } else {
        echo 'Failed to share receipt to ' . $target . '<br>';
    }
}
?>
