<?php

// Establish a connection to the 'order_database'
$conn = mysqli_connect("localhost", "root", "", "order_database");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_errno());
}
?>
