<?php

require_once 'connection.php';

if (isset($_POST['signup'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password_1'];
    $cpass = $_POST['password_2'];

    if ($password == $cpass) {
        // Hash the password before storing it
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Use a prepared statement to insert user details securely
        $stmt = $conn->prepare("INSERT INTO users_tbl (Username, Email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            echo '<div style="color: green; text-align: center;">Account created. You can login.</div>';
            header("refresh:2;register.php");
        } else {
            echo '<div style="color: red; text-align: center;">Sorry, the account was not created. Try again.</div>';
            header("refresh:2;register.php");
        }

        $stmt->close(); // Close the prepared statement
    } else {
        echo '<div style="color: red; text-align: center;">The passwords do not match. Please confirm the correct password.</div>';
        header("refresh:5;register.php");
    }

    $conn->close(); // Close the database connection
}
?>
