<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Orders to Excel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            text-align: center;
            background-color: #f0f8ff;
        }
        .button-container {
            margin-top: 50px;
        }
        .export-button {
            padding: 10px 20px;
            background-color: #0073e6;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .export-button:hover {
            background-color: #005bb5;
        }
    </style>
</head>
<body>
    <h1>Export Orders to Excel</h1>
    <p>Click the button below to export the orders data to an Excel file.</p>
    <div class="button-container">
        <form action="export_to_excel.php" method="post">
            <button type="submit" class="export-button">Export to Excel</button>
        </form>
    </div>
</body>
</html>
