<?php
// Start the session at the top of the script
session_start();

require_once 'connection.php';

$error_message = '';

// Check if there's an error message in the session
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the error message from the session
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password_1'];

    // Retrieve the stored hashed password for the given username
    $query = "SELECT * FROM users_tbl WHERE Username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        // Verify the entered password against the hashed password
        if (password_verify($password, $row['password'])) {
            // Set session variables
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['Username'];

            // Redirect to the dashboard or protected page
            header("Location: order.php");
            exit();
        } else {
            // Incorrect password
            $_SESSION['error_message'] = "Your password or username mismatch. Try again.";
            header("Location: register.php");
            exit();
        }
    } else {
        // Username not found
        $_SESSION['error_message'] = "Your password or username mismatch. Try again.";
        header("Location: register.php");
        exit();
    }

    $stmt->close();
}
?>
