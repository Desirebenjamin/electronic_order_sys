<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About_Us:</title>
    <link rel="stylesheet" href="Login.css">
</head>
<body>
    <div class="main">
        <div class="description">
            <h1>About_Us:</h1>
            <br><p>The <b><i>Organizational Database</i></b> is a management system that captures, retrieves and analyses information of 
                of different aunthenticated Organizations</p>
            <br><p>Different Organizations upload and Update their public and private data regarding the different services 
                public information in their systems</p>
            <br><p>On the other hand, we capture all the information from both the Internal and External Users 
                of diffrent organisations and retrieve it were neccessary</p>
            <br><br>
            <b><i><big><big>Thanks </big></big> for Supporting Us</i></b>
            </div>
            <br><br><><b><big>Back To Home:</big></b>
                    <button type="submit"><a href="./index.html">Home</a></button>
                    <br><br><div class = "footer">
                        <center><P> Desirebenjamin_Copright &copy; 2022</P></center> 
    </div>
</body>
</html>