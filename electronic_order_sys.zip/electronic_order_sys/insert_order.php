<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "order_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the order data from POST (assuming it's passed via POST)
$orderData = json_decode($_POST['orderReceipt'], true);

// Prepare the order details
$orderNumber = $orderData['orderNumber'];
$orderDate = date('Y-m-d', strtotime($orderData['orderDate']));
$orderTime = $orderData['orderTime'];
$customerName = $orderData['customerName'];
$customerContact = $orderData['customerContact'];
$totalPrice = floatval(str_replace(['Ugx', ','], '', $orderData['totalPrice']));
$itemsJson = json_encode($orderData['items']);
$timestamp = date('Y-m-d H:i:s');

// Insert order details into database
$stmt = $conn->prepare("INSERT INTO orders (order_number, order_date, order_time, customer_name, customer_contact, items, total_price, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssds", $orderNumber, $orderDate, $orderTime, $customerName, $customerContact, $itemsJson, $totalPrice, $timestamp);
$stmt->execute();

// Close connection
$stmt->close();
$conn->close();

// Redirect to receipt.php to generate and display the receipt
header("Location: receipt.php?orderNumber=" . urlencode($orderNumber));
exit();
?>
