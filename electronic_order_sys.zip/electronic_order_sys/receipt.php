<?php

// Start the session to access session variables
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "order_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve order number from GET
$orderNumber = $_GET['orderNumber'];

// Fetch order details from database
$stmt = $conn->prepare("SELECT * FROM orders WHERE order_number = ?");
$stmt->bind_param("s", $orderNumber);
$stmt->execute();
$result = $stmt->get_result();
$orderData = $result->fetch_assoc();

$stmt->close();
$conn->close();

// Decode items JSON
$items = json_decode($orderData['items'], true);

// Get the current logged-in user from the session
$preparedBy = $_SESSION['username'] ?? 'Unknown User';

// Calculate total price
$totalPrice = 0;
foreach ($items as $item) {
    // Remove commas and currency symbols, if any, from the price
    $price = floatval(preg_replace('/[^\d\.]/', '', $item['totalPrice']));
    $totalPrice += $price;
}

// Format total price with comma separation for thousands
$formattedTotalPrice = number_format($totalPrice, 2);

// Add total price to the orderData array
$orderData['total_price'] = $formattedTotalPrice;

// Generate the receipt
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Receipt</title>
    <link rel="stylesheet" href="receipt.css">
</head>
<body>
    <div class="action-buttons-top">
        <form action="excelsheet.php" method="post">
            <input type="hidden" name="orderReceipt" value=\'' . json_encode($orderData) . '\'>
            <button type="submit">Advanced Options</button>
        </form>
    </div>
    <div class="content-container">
        <div class="logo">
            <img src="images/Kales22.png" alt="Company Logo" width="80" id="company-logo">
        </div>
        <div id="receipt-content">
            <div class="order-details">
                <h2>Order Receipt</h2>
                <p><strong>Order Number:</strong> <span id="order-number">' . htmlspecialchars($orderData['order_number']) . '</span></p>
                <p><strong>Date:</strong> <span id="order-date">' . htmlspecialchars($orderData['order_date']) . '</span></p>
                <p><strong>Time:</strong> <span id="order-time">' . htmlspecialchars($orderData['order_time']) . '</span></p>
                <p><strong>Customer Name:</strong> <span id="customer-name">' . htmlspecialchars($orderData['customer_name']) . '</span></p>
                <p><strong>Customer Contact:</strong> <span id="customer-contact">' . htmlspecialchars($orderData['customer_contact']) . '</span></p>

                <h3>Order Items</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Price (each)</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody id="order-items">';

foreach ($items as $item) {
    echo '<tr>
            <td>' . htmlspecialchars($item['name']) . '</td>
            <td>' . htmlspecialchars($item['quantity']) . '</td>
            <td>' . htmlspecialchars($item['priceEach']) . '</td>
            <td>' . htmlspecialchars($item['totalPrice']) . '</td>
        </tr>';
}

echo '</tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                            <td id="total-price">UGX ' . htmlspecialchars($formattedTotalPrice) . '</td>
                        </tr>
                    </tfoot>
                </table>

                <div class="signature-section">
                    <div class="signature-box">
                        <div class="section-title">Prepared By</div>
                        <p><strong>Prepared By:</strong></p>
                        <p><strong style="font-weight: bold; color: #000000;">' . htmlspecialchars($preparedBy) . '</strong></p>
                    </div>

                    <div class="signature-box">
                        <div class="section-title">Received By</div>
                        <p><strong>Receiver:</strong> <span id="receiver-name"></span></p>
                    </div>
                    <div class="signature-box">
                        <div class="section-title">Packed By / Supervisor</div>
                        <p><strong>Name:</strong> <span id="packer-name"></span></p>
                        <p><strong>Signature:</strong> <img id="packer-signature" src="" alt="Packer\'s Signature"></p>
                    </div>
                </div>
                
                <div class="signature-section">
                    <div class="signature-box">
                        <div class="section-title">Approval</div>
                        <p><strong>Approved By:</strong> <span id="supervisor-name"></span></p>
                        <p><strong>Signature:</strong></p>
                    </div>
                    <div class="signature-box">
                        <div class="section-title">Security Officer</div>
                        <p><strong>Name:</strong> <span id="security-name"></span></p>
                        <p><strong>Signature:</strong> <img id="security-signature" src="" alt="Security Officer\'s Signature"></p>
                    </div>
                </div>
                
                <div class="footer">
                    <p>Thank you for your order!</p>
                    <p id="receipt-time">' . date('Y-m-d H:i:s') . '</p>
                </div>
            </div>
        </div>
    </div>
    <div class="action-buttons-bottom">
        <button onclick="saveReceipt()">Save Receipt</button>
        <button onclick="printReceipt()">Print Receipt</button>
        <button onclick="shareReceipt()">Share Receipt</button>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        function saveReceipt() {
            const element = document.getElementById("receipt-content");
            html2pdf().set({
                margin: 0.5,
                filename: "receipt.pdf",
                image: { type: "jpeg", quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true },
                jsPDF: { unit: "in", format: "a5", orientation: "portrait" }
            }).from(element).save().then(() => {
                showPrintShareOptions();
            });
        }

        function printReceipt() {
            window.print();
        }

        function shareReceipt() {
            const orderNumber = document.getElementById("order-number").textContent;
            const request = new XMLHttpRequest();
            request.open("POST", "share.php", true);
            request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            request.onreadystatechange = function () {
                if (request.readyState === XMLHttpRequest.DONE) {
                    if (request.status === 200) {
                        alert("Receipt has been shared.");
                    } else {
                        alert("Failed to share receipt.");
                    }
                }
            };
            request.send("orderNumber=" + encodeURIComponent(orderNumber) + "&totalPrice=" + encodeURIComponent("' . $formattedTotalPrice . '"));
        }
    </script>
</body>
</html>';
?>
