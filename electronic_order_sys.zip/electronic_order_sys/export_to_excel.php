<?php
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "order_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch order data from the database
$sql = "SELECT order_number, order_date, order_time, customer_name, customer_contact, total_price, timestamp FROM orders";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set document properties
    $spreadsheet->getProperties()->setCreator('Your Company')
        ->setLastModifiedBy('Your Company')
        ->setTitle('Order Information')
        ->setSubject('Order Information')
        ->setDescription('Order details exported to Excel.');

    // Add heading
    $sheet->setCellValue('A1', 'Order Number');
    $sheet->setCellValue('B1', 'Order Date');
    $sheet->setCellValue('C1', 'Order Time');
    $sheet->setCellValue('D1', 'Customer Name');
    $sheet->setCellValue('E1', 'Customer Contact');
    $sheet->setCellValue('F1', 'Total Price');
    $sheet->setCellValue('G1', 'Timestamp');

    // Populate data rows
    $row = 2;
    while ($order = $result->fetch_assoc()) {
        $sheet->setCellValue('A' . $row, $order['order_number']);
        $sheet->setCellValue('B' . $row, $order['order_date']);
        $sheet->setCellValue('C' . $row, $order['order_time']);
        $sheet->setCellValue('D' . $row, $order['customer_name']);
        $sheet->setCellValue('E' . $row, $order['customer_contact']);
        $sheet->setCellValue('F' . $row, $order['total_price']);
        $sheet->setCellValue('G' . $row, $order['timestamp']);
        $row++;
    }

    // Set headers for download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="OrderData.xlsx"');
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit();
} else {
    echo "No orders found.";
}

$conn->close();
?>
