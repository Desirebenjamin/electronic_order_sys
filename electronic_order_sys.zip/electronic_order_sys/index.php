<!DOCTYPE html> <html lang="en" class="no-js">
    <head>
    	<!-- meta charec set -->
        <meta charset="utf-8">
		<!-- Always force latest IE rendering engine or request Chrome Frame -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<!-- Page Title -->
        <title>Kales22 Beverages</title>		
		<!-- Meta Description -->
        <meta name="description" content="Organisational database">
        <meta name="keywords" content="Organisational database">
        <meta name="author" content="">
		<!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Google Font -->
		
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

		<!-- CSS
		================================================== -->
		<!-- Fontawesome Icon font -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- Twitter Bootstrap css -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- jquery.fancybox  -->
        <link rel="stylesheet" href="css/jquery.fancybox.css">
		<!-- animate -->
        <link rel="stylesheet" href="css/animate.css">
		<!-- Main Stylesheet -->
        <link rel="stylesheet" href="css/main.css">
		<!-- media-queries -->
        <link rel="stylesheet" href="css/media-queries.css">

		<!-- Modernizer Script for old Browsers -->
        <script src="js/modernizr-2.6.2.min.js"></script>

    </head>
	
    <body id="body">
	
		<!-- preloader -->
		<div id="preloader">
			<img src="img/preloader.gif" alt="Preloader">
		</div>
		<!-- end preloader -->

        <!-- 
        Fixed Navigation
        ==================================== -->
        <header id="navigation" class="navbar-fixed-top navbar">
            <div class="container">
                <div class="navbar-header">
                    <!-- responsive nav button -->
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-bars fa-2x"></i>
                    </button>
					<!-- /responsive nav button -->
					
					<!-- logo -->
                    <a class="navbar-brand" href="#body">
						<h1 id="logo">
							<img src="img/logo-1.png" alt="My Website">
						</h1>
					</a>
					<!-- /logo -->
                </div>

				<!-- main nav -->
                <nav class="collapse navbar-collapse navbar-right" role="navigation">
                    <ul id="nav" class="nav navbar-nav">
                        <li class="current"><a href="index.html">Home</a></li>
                        <li><a href="#">Invite</a></li>
                        <li><a href="About_Us.php">ContactUs</a></li>
						<li><a href="#">FAQs</a></li>
						<li><a href="#">Log Out</a></li>

                    </ul>
                </nav>
				<!-- /main nav -->
				
            </div>
        </header>
        <!--
        End Fixed Navigation
        ==================================== -->
		
		
		
        <!--
        Home Slider
        ==================================== -->
		
		<section id="slider">
        	<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

        		<!-- Indicators bullet -->
        		<ol class="carousel-indicators">
        			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
        			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
        		</ol>        		<div class="carousel-inner" role="listbox">

        			<!-- single slide -->
        			<div class="item active" style="background-image: url(img/banner1.png);">
        				<div class="carousel-caption">
        					<h2 data-wow-duration="700ms" data-wow-delay="500ms" class="wow bounceInDown animated">Welcome <span> HERE</span>!</h2>
        					<p data-wow-duration="1000ms" class="wow slideInRight animated">At your Service</p>
        					<ul class="social-links text-center">
        						<li><a href="" target="_blank"><img src="img/twitters.png" width="20px" height="20px"></a></li>
        						<li><a href="" target="_blank"><img src="img/facebook.png" width="20px" height="20px"></a></li>
        						<li><a href="Error.php"><img src="img/dribbbles.png" width="20px" height="20px" ></a></li>
        					</ul>
        					<li><a href="register.php">Login Here! Or SignUp</a></li><br>
        					<li><a href="" target="_blank"><button class="btn btn-outline-success btn-primary"><span><strong>CLICK HERE!</strong></span></button></a>  For<strong> ANY</strong> of our agents near your L<img src="img/location-icon.png" width="14px" height="19px">cation.</li>
        				</div>
        			</div>
        		</div>
        	</div>
        </section>
		
        <!--
        End Home SliderEnd
        ==================================== -->
		
		
		</section>
		
        <!--
        Meet Our Team
        ==================================== -->		
		
		<section id="team" class="team">
			<div class="container">
				<div class="row">
		
					<div class="sec-title text-center wow fadeInUp animated" data-wow-duration="700ms">
						<h2>Meet Our Team</h2>
						<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
					</div>
					
					<div class="sec-sub-title text-center wow fadeInRight animated" data-wow-duration="500ms">
						<p>This is our team of experts that make the magical services possible for you!</p>
					</div>

					<!-- single member -->
					<figure class="team-member col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp animated" data-wow-duration="500ms">
						<div class="member-thumb">
							<img src="img/team/Kales22.png" alt="Team Member" class="img-responsive">
							<figcaption class="overlay">
								<h5>We wake Up everyday to refine why we should selflessly serve you </h5>
								<p>Thanks for Supporting us!</p>
								<ul class="social-links text-center">
									<li><a href="" target="_blank"><img src="img/twitters.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/facebook.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/dribbbles.png" width="20px" height="20px"></a></li>
								</ul>
							</figcaption>
						</div>
						<h4>Name Name</h4>
						<span>Executive Director (CEO)</span>
					</figure>
					<!-- end single member -->
					
					<!-- single member -->
					<figure class="team-member col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp animated" data-wow-duration="500ms" data-wow-delay="300ms">
						<div class="member-thumb">
							<img src="img/team/Kales22.png" alt="Team Member" class="img-responsive">
							<figcaption class="overlay">
								<h5>We wake Up everyday to refine why we should selflessly serve you </h5>
								<p>Thanks for Supporting us!</p>
								<ul class="social-links text-center">
									<li><a href="" target="_blank"><img src="img/twitters.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/facebook.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/dribbbles.png" width="20px" height="20px"></a></li>
								</ul>
							</figcaption>
						</div>
						<h4>Name Name</h4>
						<span>Managing Director (COO)</span>
					</figure>
					<!-- end single member -->
					
					<!-- single member -->
					<figure class="team-member col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp animated" data-wow-duration="500ms" data-wow-delay="600ms">
						<div class="member-thumb">
							<img src="img/team/Kales22.png" alt="Team Member" class="img-responsive">
							<figcaption class="overlay">
								<h5>We wake Up everyday to refine why we should selflessly serve you </h5>
								<p>Thanks for Supporting us!</p>
								<ul class="social-links text-center">
									<li><a href="" target="_blank"><img src="img/twitters.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/facebook.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/dribbbles.png" width="20px" height="20px"></a></li>
								</ul>
							</figcaption>
						</div>
						<h4>Name Name</h4>
						<span>Chief Finance</span>
					</figure>
					<!-- end single member -->
					
					<!-- single member -->
					<figure class="team-member col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp animated" data-wow-duration="500ms" data-wow-delay="900ms">
						<div class="member-thumb">
							<img src="img/team/Kales22.png" alt="Team Member" class="img-responsive">
							<figcaption class="overlay">
								<h5>We wake Up everyday to refine why we should selflessly serve you </h5>
								<p>Thanks for Supporting us!</p>
								<ul class="social-links text-center">
									<li><a href="" target="_blank"><img src="img/twitters.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/facebook.png" width="20px" height="20px"></a></li>
									<li><a href="" target="_blank"><img src="img/dribbbles.png" width="20px" height="20px"></a></li>
								</ul>
							</figcaption>
						</div>
						<h4>Name Name</h4>
						<span>Human Resource Manager</span>
					</figure>
					<!-- end single member -->
					
				</div>
			</div>
		</section>
		
        <!--
        End Meet Our Team
        ==================================== -->
		<!--
        Contact Us
        ==================================== -->		
		
		<section id="contact" class="contact">
			<div class="container">
				<div class="row mb50">
				
					<div class="sec-title text-center mb50 wow fadeInDown animated" data-wow-duration="500ms">
						<h2>Let’s Discuss</h2>
						<div class="devider"><i class="fa fa-heart-o fa-lg"></i></div>
					</div>
					
					<div class="sec-sub-title text-center wow rubberBand animated" data-wow-duration="1000ms">
						<p>You can always share your feedback about our services here!</p>
					</div>
					
					<!-- contact form -->
					<div class="col-lg-8 col-md-8 col-sm-7 col-xs-12 wow fadeInDown animated" data-wow-duration="500ms" data-wow-delay="300ms">
						<div class="contact-form">
							<h3>Say hello!</h3>
							<form action="#" id="contact-form">
								<div class="input-group name-email">
									<div class="input-field">
										<input type="text" name="name" id="name" placeholder="Name" class="form-control">
									</div>
									<div class="input-field">
										<input type="email" name="email" id="email" placeholder="Email" class="form-control">
									</div>
								</div>
								<div class="input-group">
									<textarea name="message" id="message" placeholder="Message" class="form-control"></textarea>
								</div>
								<div class="input-group">
									<input type="submit" id="form-submit" class="pull-right" value="Send message">
								</div>
							</form>
						</div>
					</div>
					<!-- end contact form -->
					
					<!-- footer social links -->
					<div class="col-lg-1 col-md-1 col-sm-1 col-xs-12 wow fadeInRight animated" data-wow-duration="500ms" data-wow-delay="600ms">
						<ul class="footer-social">
							<li><a href="" target="_blank"><img src="img/twitters.png" width="20px" height="20px"></a></li>
							<li><a href="" target="_blank"><img src="img/facebook.png" width="20px" height="20px"></a></li>
							<li><a href="" target="_blank"><img src="img/dribbbles.png" width="20px" height="20px"></a></li>
						</ul>
					</div>
					<!-- end footer social links -->
					
				</div>
			</div>
			
			<!-- Google map -->
			<div id="map_canvas" class="wow bounceInDown animated" data-wow-duration="500ms"></div>
			<!-- End Google map -->
			
		</section>
		
        <!--
        End Contact Us
        ==================================== -->
		
		
		<footer id="footer" class="footer">
			<div class="container">
				<div class="row">
				
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-duration="500ms">
						<div class="footer-single">
							<img src="img/footer-logo1.png" alt="">
							<p>We are one of the leading organizations in Uganda and Africa at large. And it's just because we put our clients FIRST.</p>
						</div>
					</div>
				
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-duration="500ms" data-wow-delay="300ms">
						<div class="footer-single">
							<h6>Subscribe </h6>
							<form action="#" class="subscribe">
								<input type="text" name="subscribe" id="subscribe">
								<input type="submit" value="&#8594;" id="subs">
							</form>
							<p>You can always subscribe to our newsletter to keep updated about all our services. </p>
						</div>
					</div>
				
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeInUp animated" data-wow-duration="500ms" data-wow-delay="900ms">
						<div class="footer-single">
							<h6>Support</h6>
							<ul>
								<li><a href="./About_Us.html">Contact Us</a></li>
								<li><a href="#">Help Center</a></li>
							</ul>
						</div>
					</div>
					
				</div>
				<div class="row">
					<div class="col-md-12">
						<p class="copyright text-center">
							Copyright © 2024 <a href="#"> KALES22 </a>. All rights reserved.</a>
						</p>
					</div>
				</div>
			</div>
		</footer>
		
		<a href="javascript:void(0);" id="back-top"><i class="fa fa-angle-up fa-3x"></i></a>

		<!-- Essential jQuery Plugins
		================================================== -->
		<!-- Main jQuery -->
        <script src="js/jquery-1.11.1.min.js"></script>
		<!-- Single Page Nav -->
        <script src="js/jquery.singlePageNav.min.js"></script>
		<!-- Twitter Bootstrap -->
        <script src="js/bootstrap.min.js"></script>
		<!-- jquery.fancybox.pack -->
        <script src="js/jquery.fancybox.pack.js"></script>
		<!-- jquery.mixitup.min -->
        <script src="js/jquery.mixitup.min.js"></script>
		<!-- jquery.parallax -->
        <script src="js/jquery.parallax-1.1.3.js"></script>
		<!-- jquery.countTo -->
        <script src="js/jquery-countTo.js"></script>
		<!-- jquery.appear -->
        <script src="js/jquery.appear.js"></script>
		<!-- Contact form validation -->
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.form/3.32/jquery.form.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.11.1/jquery.validate.min.js"></script>
		<!-- Google Map -->
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
		<!-- jquery easing -->
        <script src="js/jquery.easing.min.js"></script>
		<!-- jquery easing -->
        <script src="js/wow.min.js"></script>
		<script>
			var wow = new WOW ({
				boxClass:     'wow',      // animated element css class (default is wow)
				animateClass: 'animated', // animation css class (default is animated)
				offset:       120,          // distance to the element when triggering the animation (default is 0)
				mobile:       false,       // trigger animations on mobile devices (default is true)
				live:         true        // act on asynchronously loaded content (default is true)
			  }
			);
			wow.init();
		</script> 
		<!-- Custom Functions -->
        <script src="js/custom.js"></script>
		
		<script type="text/javascript">
			$(function(){
				/* ========================================================================= */
				/*	Contact Form
				/* ========================================================================= */
				
				$('#contact-form').validate({
					rules: {
						name: {
							required: true,
							minlength: 2
						},
						email: {
							required: true,
							email: true
						},
						message: {
							required: true
						}
					},
					messages: {
						name: {
							required: "Come on, you have a name don't you?",
							minlength: "your name must consist of at least 2 characters"
						},
						email: {
							required: "no email, no message"
						},
						message: {
							required: "Ummm...yeah, you have to write something to send this form.",
							minlength: "thats all? really?"
						}
					},
					submitHandler: function(form) {
						$(form).ajaxSubmit({
							type:"POST",
							data: $(form).serialize(),
							url:"process.php",
							success: function() {
								$('#contact-form :input').attr('disabled', 'disabled');
								$('#contact-form').fadeTo( "slow", 0.15, function() {
									$(this).find(':input').attr('disabled', 'disabled');
									$(this).find('label').css('cursor','default');
									$('#success').fadeIn();
								});
							},
							error: function() {
								$('#contact-form').fadeTo( "slow", 0.15, function() {
									$('#error').fadeIn();
								});
							}
						});
					}
				});
			});
		</script>
    </body>
</html>
