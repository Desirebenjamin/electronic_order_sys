<?php
// Define the file path
$targetPath = 'C:/Users/DELL/Desktop/SharedReceipts';

// Check if the directory exists, if not create it
if (!file_exists($targetPath)) {
    if (!mkdir($targetPath, 0777, true)) {
        die('Failed to create directory: ' . $targetPath);
    } else {
        echo 'Directory created successfully: ' . $targetPath . '<br>';
    }
}

// File name and content for testing
$fileName = 'test_file.txt';
$filePath = $targetPath . '/' . $fileName;
$fileContent = 'This is a test file.';

// Attempt to write the file
if (file_put_contents($filePath, $fileContent)) {
    echo 'File created successfully at: ' . $filePath;
} else {
    echo 'Failed to create file at: ' . $filePath;
}
?>
